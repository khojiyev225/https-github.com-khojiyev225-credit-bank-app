const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../frontend')));
app.get('/api/applications', (req, res) => {
    fs.readFile(DATA_FILE, (err, data) => {
        if (err) return res.status(500).send('Ошибка чтения базы');
        res.json(JSON.parse(data));
    });
});
app.post('/api/applications', (req, res) => {
    const appData = req.body;
    fs.readFile(DATA_FILE, (err, data) => {
        if (err) return res.status(500).send('Ошибка');
        const apps = JSON.parse(data);
        apps.push(appData);
        fs.writeFile(DATA_FILE, JSON.stringify(apps, null, 2), err => {
            if (err) return res.status(500).send('Ошибка записи');
            res.status(201).send('OK');
        });
    });
});
app.listen(PORT, () => console.log(`Сервер на http://localhost:${PORT}`));
