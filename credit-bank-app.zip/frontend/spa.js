const app = document.getElementById("app");
const pages = {
    home: "<h2>Добро пожаловать</h2><p>Выгодные условия для всех!</p>",
    loans: "<h2>Виды кредитов</h2><ul><li>Потребительский</li><li>Ипотека</li><li>Автокредит</li></ul>",
    apply: `<h2>Заявка</h2>
        <form id="loan-form">
            <label>Имя: <input type="text" name="name" required></label><br>
            <label>Сумма: <input type="number" name="amount" required></label><br>
            <label>Срок: <input type="number" name="term" required></label><br>
            <button type="submit">Отправить</button>
        </form><div id="form-message"></div>`,
    admin: "<h2>Заявки</h2><div id='applications'></div>"
};
function renderPage(page) {
    app.innerHTML = pages[page] || "<p>Страница не найдена</p>";
    if (page === "apply") initForm();
    if (page === "admin") renderApplications();
}
function initForm() {
    const form = document.getElementById("loan-form");
    const msg = document.getElementById("form-message");
    form.addEventListener("submit", e => {
        e.preventDefault();
        const data = {
            name: form.name.value,
            amount: parseFloat(form.amount.value),
            term: parseInt(form.term.value),
        };
        data.monthly = (data.amount * 0.1 / 12) / (1 - Math.pow(1 + 0.1 / 12, -data.term));
        fetch('/api/applications', {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        }).then(() => {
            msg.textContent = "Заявка отправлена!";
            form.reset();
        });
    });
}
function renderApplications() {
    const container = document.getElementById("applications");
    fetch('/api/applications')
        .then(res => res.json())
        .then(data => {
            if (!data.length) {
                container.innerHTML = "<p>Заявок нет</p>";
                return;
            }
            container.innerHTML = "<ul>" + data.map(a =>
                `<li>${a.name}: ${a.amount}₽ на ${a.term} мес. (${a.monthly.toFixed(2)}₽/мес)</li>`
            ).join("") + "</ul>";
        });
}
document.querySelectorAll("nav a").forEach(a =>
    a.addEventListener("click", e => {
        e.preventDefault();
        renderPage(e.target.dataset.page);
    }));
renderPage("home");
